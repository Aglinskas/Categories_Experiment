About "Word_Similarity_Matrix.xlsx":

This excel file contains a word similarity matrix based on rank-ordering the 534 neighbors of each word by largest to smallest cosine similarity. The first column gives one of the 535 words in the sample, followed by 534 columns containing the most to least similar words of those in the sample.

